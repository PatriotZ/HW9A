const circle= require("./circle");
console.log(circle.circumference(3));
console.log(circle.area(3));