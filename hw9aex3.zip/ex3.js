{
    "name": "Problem 3",
    "version": "1.1",
    "lockfileVersion": 1,
    "requires": true,
    "dependencies": {
      "moment": {
        "version": "1.3.1",
        "resolved": "https://registry.npmjs.org/moment/-/moment-2.29.1.tgz",
        "integrity": "sha512-kHmoybcPV8Sqy59DwNDY3Jefr64lK/by/da0ViFcuA4DH0vQg5Q6Ze5VimxkfQNSC+Mls/Kx53s7TjP1RhFEDQ=="
      }
    }
  }